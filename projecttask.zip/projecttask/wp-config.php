<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'webprphi_projecttask' );

/** MySQL database username */
define( 'DB_USER', 'webprphi_projecttaks' );

/** MySQL database password */
define( 'DB_PASSWORD', '~rbG1D4m#;Rc' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '&^otm|;bNQ`u zd}pl@1=h?cW12ZPbA?T%,G9cHQ$ ?3F<m}tC#_Xt]t#=d8S:$6' );
define( 'SECURE_AUTH_KEY',  'cyf:@_mW_VH$Ume{Ln9sdV=ZBgL!~%FC6hQLA ndR6=bX`0Ob,TwY/(M[fvtfY0V' );
define( 'LOGGED_IN_KEY',    'aPD_W~VT)GC>5?_tuVB!N]5#06G[n_UOq9s35hIiwn%KVgun0+cX,%0M^O_K_NpT' );
define( 'NONCE_KEY',        '8T6xcIC_?kxb)P(jc1r_txF|$z7>GeL-KPp^.<Huil1&r!UW!oi8xw/UmMmBlvZX' );
define( 'AUTH_SALT',        'BV;vy, .YZ`E;g]XQ eT_h$Mns]K> e.j @2)f|R%xHe-.6Guu_-?0[4|8/T}+QX' );
define( 'SECURE_AUTH_SALT', '!CBH0gJ+rg^v9&wKqcd3;)N$-P>$yhoGLRt!iR(rC&)UCH.u7&1tvg1<XDst>QBP' );
define( 'LOGGED_IN_SALT',   'I[gbVCVKx% AFdJtgb05zS$o,nXy{GCF:[nbyoF=oQMb[7.mb`T6|#ed.hTGk_j*' );
define( 'NONCE_SALT',       'CDP-prN11&te{WNjd4t9d|W#lU00YH1Wo{7`,eSbv[3Wftq7P+UF%_vG*Ug?:rqm' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
